﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Threading;
using System.Drawing;
using System.Drawing.Imaging;
using Console = Colorful.Console;
using System.Runtime.InteropServices;
using System.IO;

namespace pClasses
{
    class Program
    {
        
        //Création des listes
        static List<Produit> lsItems = new List<Produit>();
        static List<Fournisseur> lsFournisseurs = new List<Fournisseur>();
        static List<Rayon> lsRayon = new List<Rayon>();
        static List<Achat> lsPanier = new List<Achat>();
        static List<int> Numeroentre = new List<int>();
        
        /// <summary>
        /// Méthode pour afficher les choix du menu
        /// </summary>
        static void Menu()
        {

            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("1. Afficher un article ");
            Console.WriteLine("2. Ajouter un item a votre panier ");
            Console.WriteLine("3. Modifier un item dans votre panier ");
            Console.WriteLine("4. Confirmer la facture ");
            Console.WriteLine("5. Supprimer une facture ");
            Console.WriteLine("6. Sauvegarder une facture ");
            Console.WriteLine("7. Ouvrir une facture ");
            Console.WriteLine("8. Quitter ");
            Console.WriteLine("---------------------------------------------");
        }
        /// <summary>
        /// Méthode pour le choix du menu
        /// </summary>
        /// <returns></returns>
        static int ChoixMenu()
        {
            int choix;
            Menu();
            while (true)
            {
                Console.Write("Entrez votre choix du menu : ");
                while (!int.TryParse(Console.ReadLine(), out choix) || choix < 1 || choix > 8)
                {
                    Console.Write("Il faut entrer un nombre entre 0 et 7 : ", Color.Red);
                }
                break;

            }

            return choix;
        }
        /// <summary>
        /// Méthode pour l'info du client
        /// </summary>
        static void InfoClient()
        {
            int numero;
            Client client2 = new Client();
            Console.Write("Quel est votre numéro favoris : ");
            while (!int.TryParse(Console.ReadLine(), out numero))
            {
                Console.WriteLine("Il faut entrer un nombre Entier", Color.Red);
                Console.Write("Quel est votre numéro favoris : ");
            }
            Console.Write("Quel est votre nom : ");
            string nom = Console.ReadLine();
            Console.Write("Quel est votre prénom : ");
            string prenom = Console.ReadLine();
            Console.Write("Quel est votre adresse : ");
            string adresse = Console.ReadLine();
            Console.Write("Quel est votre ville : ");
            string ville = Console.ReadLine();
            Console.Write("Quel est votre province : ");
            string province = Console.ReadLine();
            Console.Write("Quel est votre numéro de téléphone : ");
            string tele = Console.ReadLine();

            client2.NoTelephone = tele;
            while (client2.NoTelephone == "XXX")
            {
                Console.WriteLine("Il faut entrer un numéro valide");
                Console.Write("Quel est votre numéro de téléphone : ");
                tele = Console.ReadLine();
                client2.NoTelephone = tele;
            }
            Client client1 = new Client(numero, nom, prenom, adresse, ville, province, tele);
            client1.AfficherClient();

        }
        /// <summary>
        /// Méthode pour creer les produits
        /// </summary>
        static void CreerProduits()
        {

            //Les lsItems qui sont dans le magasin
            //Création des produits, fournisseurs et rayons
            lsFournisseurs.Add(new Fournisseur(1, "Fruitsi Co", "fruitsico@gmail.com", "8192345343"));
            lsRayon.Add(new Refrigerateur(1.7f, 3.3f, 1, "Fruits et légumes", 100.1f));
            lsFournisseurs.Add(new Fournisseur(1, "Fruitsi Co", "fruitsico@gmail.com", "8192345343"));
            lsRayon.Add(new Refrigerateur(1.7f, 3.3f, 1, "Fruits et légumes", 100.1f));
            lsFournisseurs.Add(new Fournisseur(1, "Fruitsi Co", "fruitsico@gmail.com", "8192345343"));
            lsRayon.Add(new Refrigerateur(1.7f, 3.3f, 1, "Fruits et légumes", 100.1f));
            lsFournisseurs.Add(new Fournisseur(1, "Fruitsi Co", "fruitsico@gmail.com", "8192345343"));
            lsRayon.Add(new Refrigerateur(1.7f, 3.3f, 1, "Fruits et légumes", 100.1f));
            lsFournisseurs.Add(new Fournisseur(1, "Lait Co", "laitco@gmail.com", "8192245583"));
            lsRayon.Add(new Refrigerateur(1.7f, 3.3f, 2, "Produits Laitiers", 100.1f));
            lsFournisseurs.Add(new Fournisseur(1, "Bready Co", "breadyco@gmail.com", "8198375343"));
            lsRayon.Add(new Tablette(2, 2, "Grains", 100.1f));
            lsFournisseurs.Add(new Fournisseur(1, "Lait Co", "laitco@gmail.com", "8192245583"));
            lsRayon.Add(new Congelateur(-28.8889f, -23.3333f, 2, "Produits Laitiers", 100.1f));
            //Creer les produits

            lsItems.Add(new Produit("PO222M", 1.00f, 100, "Pomme", lsRayon[0], lsFournisseurs[0]));
            lsItems.Add(new Produit("BA222N", 2.00f, 100, "Banane", lsRayon[1], lsFournisseurs[1]));
            lsItems.Add(new Produit("LA222T", 2.29f, 100, "Laitue", lsRayon[2], lsFournisseurs[2]));
            lsItems.Add(new Produit("AS222P", 7.00f, 100, "Asperges", lsRayon[3], lsFournisseurs[3]));
            lsItems.Add(new Produit("LA222I", 6.68f, 100, "Lait", lsRayon[4], lsFournisseurs[4]));
            lsItems.Add(new Produit("PA222I", 3.59f, 100, "Pain", lsRayon[5], lsFournisseurs[5]));
            lsItems.Add(new Produit("VA222N", 3.19f, 100, "Crème Glacée Vanille", lsRayon[6], lsFournisseurs[6]));

        }
        /// <summary>
        /// Méthode pour le choix du menu 2
        /// </summary>
        static void choix1()
        {
            int cpt = 0;
            Console.Write("Quel article voulez vous afficher entrez le nom ou le no de référence : ");
            string item = Console.ReadLine();
            foreach (Produit elem in lsItems)
            {
                cpt += 1;
                
                if (item == elem.description || item == elem.noRef)
                {
                    foreach (Produit i in lsItems)
                    {
                        if (i.description == item || i.noRef == item)
                        {
                            elem.AfficherProduit();
                        }
                    }
                    break;
                }
                else
                {
                    if (cpt == lsItems.Count())
                    {
                        Console.WriteLine("L'item est invalide");
                        cpt = 0;
                    }
                }
            }
        }
        /// <summary>
        /// Méthode pour le choix du menu 2
        /// </summary>
        static void choix2()
        {

            
            string faux = "faux";
            while (faux == "faux")
            {
                int cpt = 0;
                int cpt3 = -1;
                Console.Write("Quel article voulez vous ajouter au panier faites 0 si vous voulez quitter : ");
                string item = Console.ReadLine();
                foreach (Produit elem in lsItems)
                {
                    cpt3 += 1;
                    if (item == "0")
                    {
                        faux = "vrai";
                    }
                    
                    else if (item == elem.description || item == elem.noRef)
                    {
                        if (elem.NbInv < 100)
                        {
                            System.Console.WriteLine("L'item existe déja");
                            break;
                        }
                        int quantite;
                        while (true)
                        {
                            int cpt2 = -1;
                            Console.Write("Quel est la quantité de l'item : ");
                            while (!int.TryParse(Console.ReadLine(), out quantite) || quantite < 1)
                            {
                                Console.WriteLine("Il faut entrer un nombre Entier suppérieur a 0", Color.Red);
                                Console.Write("Quel est la quantité de l'item : ");
                            }
                            foreach (Produit i in lsItems)
                            {
                                cpt2 += 1;
                                if (i.description == item || i.noRef == item)
                                {

                                    lsPanier.Add(new Achat(lsItems[cpt2], quantite, lsItems[cpt2].prixUnitaire * quantite));
                                    i.NbInv = quantite;
                                    elem.AfficherProduit();


                                }
                            }
                            break;
                        }

                    }
                    
                    else
                    {
                        cpt += 1;
                        if (cpt == 7)
                        {
                            Console.WriteLine("L'item est invalide ");
                        }
                    }
                    
                }
            }
        }
        /// <summary>
        /// méthode choix 3
        /// </summary>
        static void choix3()
        {
            int cpt3 = 0;
            int cpt = -1;
            Console.Write("Quel article voulez vous supprimer : ");
            string item = Console.ReadLine();
            foreach (Produit elem in lsItems)
            {
                cpt += 1;
                if (lsPanier.Count() == 0)
                {
                    Console.WriteLine("Le panier est vide");
                    break;
                }
                if (item == elem.description || item == elem.noRef)
                {
                    try
                    {
                        lsPanier.RemoveAt(cpt) ;
                    }
                    catch
                    {
                        if (cpt == 7)
                        {
                            Console.WriteLine("L'item n'existe pas");
                        }
                        
                    }
                    elem.NbInv = -1;
                    break;
                }
                else
                {
                    cpt3 += 1;
                    if (cpt3 == lsItems.Count())
                    {
                        Console.WriteLine("L'item est invalide");
                        cpt = 0;
                    }
                }
                
            }
        }
        /// <summary>
        /// Méthode Choix 4
        /// </summary>
        static void choix4()
        {
            float flTotal = 0;
            foreach (Achat elem in lsPanier)
            {
                flTotal += elem.montant;
            }

            Facture fac3 = new Facture();
            fac3.sousTotal = flTotal;
            //Calcule la facture
            fac3.CalculerTotalFact(fac3.CalculerTVQ(flTotal), fac3.CalculerTPS(flTotal));
            fac3.achats = lsPanier;
            //Affiche la facture
            fac3.AfficherFacture();
        }
        /// <summary>
        /// Méthode choix 5
        /// </summary>
        static void choix5()
        {
            Console.Write("Êtes vous certain/e de vouloir supprimer la facture [Y/N] : ");
            string choix = Console.ReadLine();
            if (choix == "Y")
            {
                lsPanier.Clear();
                Console.WriteLine("Votre panier sera supprimé");
                foreach (Produit i in lsItems)
                {
                    i.NbInv = -1;
                }
                return;
            }
            if (choix == "N")
            {
                Console.WriteLine("Votre panier ne sera pas supprimé");
            }
            else
            {
                Console.WriteLine("Choix invalide...");
                choix5();
            }
            
        }
        static void choix6()
        {
            float flTotal = 0;
            foreach (Achat elem in lsPanier)
            {
                flTotal += elem.montant;
            }

            Facture fac3 = new Facture();
            fac3.sousTotal = flTotal;
            //Calcule la facture
            fac3.CalculerTotalFact(fac3.CalculerTVQ(flTotal), fac3.CalculerTPS(flTotal));
            fac3.achats = lsPanier;


            File.WriteAllText("fichier.txt","---------------------IGA---------------------\n");
            foreach (Achat achat in lsPanier)
            {
                File.AppendAllText("fichier.txt",achat.quantite.ToString() + "              " + achat.Produce.description.ToString() + "              " + achat.montant.ToString() + "$\n");
            }
            File.AppendAllText("fichier.txt", "\n");
            File.AppendAllText("fichier.txt", "Sous total : " + fac3.sousTotal + "$ \n");
            File.AppendAllText("fichier.txt", "Montant TPS : " + fac3.mntTPS + "$ \n");
            File.AppendAllText("fichier.txt", "Montant TVQ : " + fac3.mntTVQ + "$ \n");
            File.AppendAllText("fichier.txt", "Total Facture : " + fac3.totalFacture + "$ \n");
            File.AppendAllText("fichier.txt", "Numéro Facture : " + fac3.numFacture()+"\n");
            File.AppendAllText("fichier.txt", "Date : " + fac3.dateFacture+"\n");
            File.AppendAllText("fichier.txt", "---------------------------------------------");
        }
        static void choix7()
        {
            Console.WriteLine(File.ReadAllText("fichier.txt"));
        }
        static void Test()
        {
            Console.Clear();
            //Test Classe Client
            InfoClient();
            Client client3 = new Client();
            client3.AfficherClient();
            //Test Classe Produit
            choix2();
            foreach (Rayon i in lsRayon)
            {
                i.AFFICHERRAYON();
            }
            //Test Classe Achat
            lsPanier.Add(new Achat(lsItems[0], 6, lsItems[0].prixUnitaire * 6));
            lsPanier.Add(new Achat(lsItems[1], 5, lsItems[1].prixUnitaire * 5));

            foreach(Achat i in lsPanier)
            {
                Console.WriteLine(i.montant);
            }
            //Test de la classe facture
            float flTotal = 0;
            
            foreach (Achat elem in lsPanier)
            {
                flTotal += elem.montant;
            }

            Facture fac3 = new Facture();
            fac3.sousTotal = flTotal;
            //Calcule la facture
            fac3.CalculerTotalFact(fac3.CalculerTVQ(flTotal), fac3.CalculerTPS(flTotal));
            fac3.achats = lsPanier;
            //Affiche la facture
            fac3.AfficherFacture();

        }


        static void Main(string[] args)
        {
            //Aficher un loading
            /*
            int cpt = 0;
            while (cpt != 100)
            {
                cpt += 1;
                Console.WriteLine("Loading : " + cpt + "%",Color.LightBlue);
                Thread.Sleep(10);
                Console.Clear();
            }
            */
            //Creer les produits
            CreerProduits();
            //Entrer un bouton pour se debarasser des chiffres bizares
            Console.ReadKey();
            Console.Clear();
            //Appeler les tests
            //Test();

            while (true)
            {
                
                int inChoix = ChoixMenu();
                if (inChoix == 1)
                {
                    choix1();
                }
                if (inChoix == 2)
                {
                    choix2();
                }
                if (inChoix == 3)
                {
                    choix3();
                }
                if (inChoix == 4)
                {
                    choix4();
                }
                if (inChoix == 5)
                {
                    choix5();
                }
                if (inChoix == 6)
                {
                    choix6();
                }
                if (inChoix == 7)
                {
                    choix7();
                }
                if (inChoix == 8)
                {
                    break;
                }
            }

            

        }
        
    }

}

