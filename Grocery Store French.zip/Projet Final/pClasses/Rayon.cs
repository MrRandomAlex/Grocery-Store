﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pClasses
{
    class Rayon
    {
        protected int noRayon;
        protected string nomRayon;
        protected float superficie;
        //Constructeur
        public Rayon()
        {
            this.noRayon = 0;
            this.nomRayon = "aucun";
            this.superficie = 0;
        }
        //constructeur de base avec param
        public Rayon(int pNoRayon,string pNomRayon, float pSuperficie)
        {
            this.noRayon = pNoRayon;
            this.nomRayon = pNomRayon;
            this.superficie = pSuperficie;
        }
        //afficher le rayon
        public void AFFICHERRAYON()
        {
            Console.WriteLine("Le rayon est : " + this.nomRayon);
            Console.WriteLine("Le no du rayon est : " + this.noRayon);
        }
    }
}
