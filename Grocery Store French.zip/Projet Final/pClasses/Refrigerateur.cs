﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pClasses
{
    class Refrigerateur : Rayon
    {
        public float degresMax;
        public float degresMin;
        //Constructeur
        public Refrigerateur()
        {
            this.degresMax = 3.3f;
            this.degresMin = 1.7f;
        }
        //constructeur de base avec param
        public Refrigerateur(float pDegresMin, float pDegresMax, int pNoRayon, string pNomRayon, float pSuperficie)
            : base(pNoRayon, pNomRayon, pSuperficie)
        {
            this.degresMax = pDegresMax;
            this.degresMin = pDegresMin;
        }
    }
}
