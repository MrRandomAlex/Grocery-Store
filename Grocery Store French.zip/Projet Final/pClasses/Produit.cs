﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Threading;
using System.Drawing;
using System.Drawing.Imaging;
using Console = Colorful.Console;

namespace pClasses
{
    class Produit
    {
        public string noRef;
        public string description;
        public float prixUnitaire;
        private Rayon rayon;
        private int nbEninventaire;
        private Fournisseur fournisseur;




        //Constructeur
        public Produit()
        {
            this.noRef = "xz923x";
            this.prixUnitaire = 0;
            this.nbEninventaire = 100;
            this.description = "produit";
            this.rayon = null;
            this.fournisseur = null;
        }
        //constructeur de base avec param
        public Produit(string pNoRef,float pPrixUnitaire, int pNbEnInventaire,string pDescription,Rayon pRayon,Fournisseur pFournisseur)
        {
            this.noRef = pNoRef;
            this.prixUnitaire = pPrixUnitaire ;
            this.nbEninventaire = pNbEnInventaire;
            this.description = pDescription;
            this.rayon = pRayon;
            this.fournisseur = pFournisseur;
            Console.Write(nbEninventaire);
        }
        //Afficher un produit
        public void AfficherProduit()
        {
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("#Référence : " + this.noRef);
            Console.WriteLine("Stock : " + this.nbEninventaire);
            Console.WriteLine("$Prix : " + this.prixUnitaire + "$");
            Console.WriteLine("Nom de l'item : " + this.description);
            Console.WriteLine("---------------------------------------------");

        }

        //Vérifie que le stock est plus grand que 0
        public int NbInv
        {
            get
            {
                return this.nbEninventaire;
            }
            set
            {
                if (value >= nbEninventaire)
                {
                    this.nbEninventaire = 0;
                }
                if (value == -1)
                {
                    this.nbEninventaire = 100;
                }
                else
                {
                    this.nbEninventaire = nbEninventaire - value;
                }
            }
        }
        //assigner le rayon
        public Rayon Rayon
        {
            get
            {
                return this.rayon;
            }
            set
            {
                this.rayon = value;
            }
        }
        //assigner le fournisseur
        public Fournisseur Fournisseur
        {
            get
            {
                return this.fournisseur;
            }
            set
            {
                this.fournisseur = value;
            }
        }


        
    
    }
    
}
