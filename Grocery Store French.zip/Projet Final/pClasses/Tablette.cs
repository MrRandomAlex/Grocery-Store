﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pClasses
{
    class Tablette : Rayon
    {
        public int noRangee;
        //Constructeur
        public Tablette()
        {
            this.noRangee = 0;
        }
        //constructeur de base avec param
        public Tablette(int pNoRangee, int pNoRayon, string pNomRayon, float pSuperficie)
            : base(pNoRayon, pNomRayon, pSuperficie)
        {
            this.noRangee = pNoRangee;
        }
        
    }
    
}
